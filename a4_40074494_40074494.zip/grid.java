//class useful
import java.util.*;

public class grid{

private position[][] chess= new position[8][8]; //chess is a 8 by 8 grid
 int cl=6,ul=6;   //at first,computer has cl ships , leftand user had ul ships left

//Construction method
grid(){
for(int i=0;i<8;i++)
for(int j=0;j<8;j++)
this.chess[i][j]= new position('_','b',false,'_');
}

//For user can put theirs ships and grenades we need to give a domain for the value input ,if a user puts i9 it's not work we should limit the user and let the user put again
public void userInput(String prompt,char type,int nb){
String coordinate="";
char row,column;
int x,y;
boolean ok1=false;
int i=1;
while(i<=nb){
System.out.print(prompt+i+": ");
Scanner kb=new Scanner(System.in);
coordinate= kb.next();
row=coordinate.charAt(1);
column=coordinate.charAt(0);
ok1=coordinate.length()==2&&(column>='A'||column>='a') &&(column<='H'|| column<='h')&&row>='1'&&row<='8';
if(ok1){
		x=row-'1';
		y=Character.toUpperCase(column)-'A';
		if(this.chess[x][y].type=='_'){ 						
		this.chess[x][y].type=type;
		this.chess[x][y].owner='u';
		i++;
		}
		else  //type!='_'
		{System.out.println("sorry, coordinates already used. try again.");}	
	}
else 	//!ok1
		System.out.println("sorry, coordinates outside the grid. try again.");
            }	//loop done
}	//userInput method

//For user can put its ships and grenades(all random) computer respects the rule so that can be more easy
public void computerInput(String prompt){
int i=0,j=0;
while(i<6){
int x=(int)(Math.random()*8);
int y=(int)(Math.random()*8);
if(this.chess[x][y].type=='_'){ 						
this.chess[x][y].type='S';
this.chess[x][y].owner='c';
i++;}}
while(j<4){
int x=(int)(Math.random()*8);
int y=(int)(Math.random()*8);
if(this.chess[x][y].type=='_'){ 						
this.chess[x][y].type='G';
this.chess[x][y].owner='c';
j++;}}
System.out.println();
System.out.println(prompt);
}
//for user shoot a rocket and also the same problem for the user limit
public boolean user_rocket(String prompt){
String coordinate="";
char row,column;
int x,y;
boolean ok1=false,ok2=false;
while(true){
System.out.print(prompt);	//prompt-"position of your(my) rocket:"
Scanner kb=new Scanner(System.in);
coordinate= kb.next();
row=coordinate.charAt(1);
column=coordinate.charAt(0);
ok1=(coordinate.length()==2)&&(column>='A'||column>='a') &&(column<='H'||column<='h') &&row>='1'&&row<='8';

x=row-'1';
y=Character.toUpperCase(column)-'A';
if(ok1&&!this.chess[x][y].call){
this.chess[x][y].call=true;
switch(this.chess[x][y].type)
{case '_': {	this.chess[x][y].display='*';
		System.out.println("nothing.");break;	
		}
case 's':  {	this.chess[x][y].display='s';
		System.out.println("ship hit.");
		this.ul--;
		break;	
		}				
case 'S':  {	this.chess[x][y].display='S';
		System.out.println("ship hit.");
		this.cl--;
		break;	
		}	
case 'g':  {	this.chess[x][y].display='g';
		System.out.println("boom�� grenade.");	
		ok2=true;
		break;}	
case 'G':  {	this.chess[x][y].display='G';
		System.out.println("boom�� grenade.");	
		ok2=true;
		break;}	
	} //switch
return ok2;
}	  //if
else if(ok1&&this.chess[x][y].call){
System.out.println("position already called.");
return ok2;}
else if(!ok1)System.out.println("sorry, coordinates outside the grid. try again.");
}	//while
}
//for user shoot a rocket
public boolean computer_rocket(String prompt){
String coordinate="";
int x,y;
boolean ok1=false,ok2=false;

System.out.print(prompt);	//prompt-"position of your(my) rocket:"
x=(int)(Math.random()*8);
y=(int)(Math.random()*8);
//String row=Integer.toString(x+1),column=(char)(y+'A');
//row='1'+x;
//column='A'+y;
char column=(char)(y+'A');
System.out.print(column);
System.out.print(x+1);
System.out.println();
if(!this.chess[x][y].call){
this.chess[x][y].call=true;
switch(this.chess[x][y].type)
{case '_': {	this.chess[x][y].display='*';
		System.out.println("nothing.");	
		break;
		}
case 's':  {	this.chess[x][y].display='s';
		System.out.println("ship hit.");
		this.ul--;
		break;	
		}				
case 'S':  {	this.chess[x][y].display='S';
		System.out.println("ship hit.");
		this.cl--;
		break;	
		}	
case 'g':  {	this.chess[x][y].display='g';
		System.out.println("boom�� grenade.");
		ok2=true;break;	
		}	
case 'G':  {	this.chess[x][y].display='G';
		System.out.println("boom�� grenade.");	
		ok2=true;break;	}	
	} 

}	  
else{
System.out.println("position already called.");
}
return ok2;
}
//this method for print grid
public void print_grid(int t)
{if(t==1){
System.out.println();
for(int i=0;i<8;i++){
for(int j=0;j<8;j++){
System.out.print(this.chess[i][j].display);//use this method for print local grid 
System.out.print(' ');}
System.out.println();}
}
else if(t==2){
System.out.println();
for(int i=0;i<8;i++){
for(int j=0;j<8;j++){
System.out.print(this.chess[i][j].type);//use this method for print the global grid when the winner out we can see all the element in this array chess
System.out.print(' ');}
System.out.println();}
}
}
}