// -------------------------------------------------------
// Assignment (No.4)
// Written by: (wei yuan and 40074494)
// Date :12/4/2020
// For COMP 248 Section (P) �C Fall 2020
// --------------------------------------------------------

public class Assignment4{
public static void main(String[] args){
boolean gc1=false,gc2=false;
grid grid1= new grid();
int ucs=1,ccs=1;
System.out.println();
System.out.println("Hi, Let's play Battleship!\n");
//Input the coordinates of user's ship
grid1.userInput("Enter the coordinates of your ship #",'s',6);

System.out.println();

//Input the coordinates of user's grenade
grid1.userInput("Enter the coordinates of your grenade #",'g',4);

grid1.computerInput("OK,the computer placed its ships and grenades at random. Let's play.");

while(true){
System.out.println("\n");
for(int i=0;i<ucs;i++){
//user shoots a rocket to a position
gc1=grid1.user_rocket("position of your rocket:");
//if gc1 is true,the rocket falls on a coordinate where has a grenade
if(gc1){ccs=2; //ccs=2 means the computer play twice in a row
grid1.print_grid(1);
break;
}
else {
ccs=1;
if(grid1.cl==0)System.out.print("You Win!");
if(grid1.ul==0)System.out.print("Computer Win!");
if((grid1.cl==0)||(grid1.ul==0)){grid1.print_grid(2);break;}
else 
grid1.print_grid(1);}
}
if((grid1.cl==0)||(grid1.ul==0))break;

for(int i=0;i<ccs;i++){
//computer shoots a rocket to a position
gc2=grid1.computer_rocket("position of my rocket:");
//if gc2 is true,the rocket falls on a coordinate where has a grenade
if(gc2){ucs=2; //ucs=2 means the user play twice in a row
grid1.print_grid(1);
break;
}
else {
ucs=1; 
if(grid1.ul==0)System.out.print("Computer Win!");//ul means user's ship left
if(grid1.cl==0)System.out.print("You Win!");  //cl means computer's ship left
if((grid1.cl==0)||(grid1.ul==0)){grid1.print_grid(2);break;}
else 
grid1.print_grid(1);
}
}
if((grid1.cl==0)||(grid1.ul==0))break;
}	//while
}	//maim()
}	//class



