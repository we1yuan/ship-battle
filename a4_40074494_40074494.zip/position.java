//class useful
public class position{
	
 char type;	//type of element at that position (a ship-'s or S', a grenade-'g or G' or nothing-'_')
 
 char owner;  //the owner of the element (the user-'u' , the computer-'c'or nothing-'b')
 
 boolean call;	//whether the position has already been called or not(true-called,false-not called)
 
 char display;	//display the element at a position(a ship-'s or S', a grenade-'g or G' or nothing-'_')
 
//Construction method
 
position(char t1,char w1,boolean c1,char d1){
	
this.type=t1;

this.owner=w1;

this.call=c1;

this.display=d1;

}

}